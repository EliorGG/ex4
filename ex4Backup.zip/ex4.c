/******************
Name: Elior Golan
ID: 331516922
Assignment: ex4
*******************/
#include <stdio.h>
#include <string.h>

#define PYRAMID_LEVELS 5
#define MAX_GRID_SIZE 20

/*
 We mark 0 in VALID because when we want to initialize arrays with 4 and 5,
 we want everything to be free to put queens/words. Also, it is convenient to initialize an array with zeros.
*/
#define VALID 0
#define INVALID 1
/*
 At the beginning of task 4, we say that there is no previous queen,
 so to avoid confusion we will mark the first previous queen with 2.
*/
#define NEUTRAL_COLUMN -2
#define MAX_SLOTS_NUM 100
#define MAX_CROSSWORD_SIZE 30
#define MAX_WORDS_NUM 100
#define MAX_WORD_SIZE 16
#define MAX_SLOT_SIZE 15

//slot struct for task5:
typedef struct {
    int row;
    int column;
    int length;
    char direction;
}Slot;
/*
All function annotations will be during implementation
But basically each helper receives the input data and calculates the result
*/
//task1 functions:
void task1_robot_paths();
int task1Helper(int x, int y);
//task2 functions:
void task2_human_pyramid();
float task2Helper(float pyramid[][PYRAMID_LEVELS], int i,int j);
//task3 functions:
void task3_parenthesis_validator();
char oppositeParenthesis(char parenthesis);
int isOpenParenthesis(char parenthesis);
int isClosedParenthesis(char parenthesis);
int task3Helper(char lastParenthesis);
//task4 functions:
void task4_queens_battle();
int task4Helper(char grid[][MAX_GRID_SIZE],int board[][MAX_GRID_SIZE],int capturedColors[][MAX_GRID_SIZE],
    int allowedColumns[MAX_GRID_SIZE],int i,int j,int prevQueenColumn,int size);
void fillColor(char grid[][MAX_GRID_SIZE],int capturedColors[][MAX_GRID_SIZE],int i,int j,char color,int fillingValue,
    int size);
//task5 functions:
void task5_crossword_generator();
int isFitIn(char board[][MAX_CROSSWORD_SIZE],Slot slot,char word[MAX_WORD_SIZE],char slotChange[MAX_SLOT_SIZE],
    int index);
void safeDelete(char board[][MAX_CROSSWORD_SIZE],Slot slot,char slotChange[MAX_SLOT_SIZE],int index);
int task5Helper(char board[][MAX_CROSSWORD_SIZE],int size,Slot slots[MAX_SLOTS_NUM],int slotsNum,
    char words [MAX_WORD_SIZE][MAX_WORDS_NUM],int availableWords[MAX_WORDS_NUM],int wordsNum,int currentSlot,
    int currentWord);

int main()
{
    int task = -1;
    do
    {
        printf("Choose an option:\n"
               "1. Robot Paths\n"
               "2. The Human Pyramid\n"
               "3. Parenthesis Validation\n"
               "4. Queens Battle\n"
               "5. Crossword Generator\n"
               "6. Exit\n");

        if (scanf("%d", &task))
        {
            switch (task)
            {
            case 6:
                printf("Goodbye!\n");
                break;
            case 1:
                task1_robot_paths();
                break;
            case 2:
                task2_human_pyramid();
                break;
            case 3:
                task3_parenthesis_validator();
                break;
            case 4:
                task4_queens_battle();
                break;
            case 5:
                task5_crossword_generator();
                break;
            default:
                printf("Please choose a task number from the list.\n");
                break;
            }
        }
        else
        {
            scanf("%*s");
        }

    } while (task != 6);
}

void task1_robot_paths(){
    printf("Please enter the coordinates of the robot (column, row):\n");
    int column=0,row=0;
    scanf( "%d %d",&column,&row);
    printf("The total number of paths the robot can take to reach home is: %d\n",task1Helper(column,row));
}

int task1Helper(int x, int y) {
    //base case:
    if(x==0 && y==0)
        return 1;
    //edge case
    if(x<0 || y<0)
        return 0;
    return task1Helper(x-1,y)+task1Helper(x,y-1);
}

void task2_human_pyramid(){
    float pyramid[PYRAMID_LEVELS][PYRAMID_LEVELS]={0};
    //input:
    printf("Please enter the weights of the cheerleaders:\n");
    for(int i=0;i<PYRAMID_LEVELS;i++) {
        for(int j=0;j<i+1;j++) {
            scanf(" %f",&pyramid[i][j]);
            if(pyramid[i][j]<0) {
                //If a negative number is entered, then return to the menu.
                printf("Negative weights are not supported.\n");
                return;
            }
        }
    }
    //output:
    printf("The total weight on each cheerleader is:\n");
    for(int i=0;i<PYRAMID_LEVELS;i++) {
        for(int j=0;j<i+1;j++)
            printf("%.2f ",task2Helper(pyramid,i,j));
        printf("\n");
    }

}


float task2Helper(float pyramid[][PYRAMID_LEVELS], int i,int j) {
    //base case:
    if(i==0)
        return pyramid[i][j];
    //edge cases:
    if(j==i)
        return 0.5*task2Helper(pyramid,i-1,j-1)+pyramid[i][j];
    if(j==0)
        return 0.5*task2Helper(pyramid,i-1,j)+pyramid[i][j];
    return 0.5*task2Helper(pyramid,i-1,j-1)+0.5*task2Helper(pyramid,i-1,j)+pyramid[i][j];
}

void task3_parenthesis_validator()
{
    printf("Please enter a term for validation:\n");
    //Clearing the buffer from whiteSpaces after receiving the number 3
    scanf(" ");
    if(task3Helper('\0'))
        printf("The parentheses are balanced correctly.\n");
    else
        printf("The parentheses are not balanced correctly.\n");
}
/*
 The function receives the last opening parenthesis in the buffer and
 returns true or false depending on what is left in the buffer.
 */
int task3Helper(char lastParenthesis) {
    char c;
    //Getting the next character in a string
    scanf("%c",&c);
    //base case with a check that there are no remaining unclosed brackets
    if(c=='\n')
        return lastParenthesis=='\0';
    /*
     If we closed the parentheses with an inappropriate parentheses, we will clear the buffer to the end
     (in the previous condition we made sure that we are not at the end, so there is definitely something in the buffer)
     and return 0 because there is no longer a chance that the string will be valid.
    */
    if(isClosedParenthesis(c) && c!=oppositeParenthesis(lastParenthesis)) {
        scanf("%*[^\n]");
        return 0;
    }
    //We closed the parenthesis: we can move on.
    if(isClosedParenthesis(c) && c==oppositeParenthesis(lastParenthesis))
        return 1;
    //If new brackets are opened then split into 2 (keeping the order)
    //But if not, we'll just keep looking for a bracket.
    int x=1;
    if(isOpenParenthesis(c))
        x=task3Helper(c);
    return x&&task3Helper(lastParenthesis);
}
//Auxiliary functions for task 3:
char oppositeParenthesis(char parenthesis) {
        if (parenthesis == '(')
            return ')';
        if(parenthesis == '[')
            return ']';
        if(parenthesis == '{')
            return '}';
        if(parenthesis == '<')
            return '>';
        return '\0';

}

int isOpenParenthesis(char parenthesis) {
    return parenthesis == '(' || parenthesis == '[' || parenthesis == '{' || parenthesis == '<';
}

int isClosedParenthesis(char parenthesis) {
    return parenthesis==')' || parenthesis== ']' || parenthesis=='}' || parenthesis=='>';
}

void task4_queens_battle(){
    char grid[MAX_GRID_SIZE][MAX_GRID_SIZE]={0};
    int board[MAX_GRID_SIZE][MAX_GRID_SIZE]={0};
    //input:
    printf("Please enter the board dimensions:\n");
    int size=0;
    scanf("%d",&size);
    printf("Please enter a %d*%d puzzle board:\n",size,size);
    for(int i=0;i<size;i++)
        for(int j=0;j<size;j++)
            scanf(" %c",&grid[i][j]);
    int capturedColors[MAX_GRID_SIZE][MAX_GRID_SIZE]={VALID},allowedColumns[MAX_GRID_SIZE]={VALID};
    //output:
    if(task4Helper(grid,board,capturedColors,allowedColumns,0,0,NEUTRAL_COLUMN,size)) {
        printf("Solution:\n");
        for(int i=0;i<size;i++) {
            for(int j=0;j<size;j++) {
                if(board[i][j]==0)
                    printf("* ");
                else
                    printf("X ");
            }
            printf("\n");
        }
    }
    else
        printf("This puzzle cannot be solved.\n");

}
/*
The function receives: the board divided into colors, the queens that we have already marked,
the board where it is written which colors are invalid, an array of invalid columns,
and the column of the previous queen (to check diagonals)
and also receives the position of the queen that is being tried to be placed
Each time the operation tries to place a queen in a row,
marks in the appropriate places which places on the board it prohibits and then drops a row
if the queen's position there does not give the solution, backtracking is done
 */
int task4Helper(char grid[][MAX_GRID_SIZE],int board[][MAX_GRID_SIZE],int capturedColors[][MAX_GRID_SIZE],
    int allowedColumns[MAX_GRID_SIZE],int i,int j,int prevQueenColumn,int size) {
    // base case(all coloums finished):
    if(i==size)
        return 1;
    //If we failed to place a queen in this row:
    if(j==size)
        return 0;
    //first tring next coulmmn,else we are mobing on:
    if(task4Helper(grid,board,capturedColors,allowedColumns,i,j+1,prevQueenColumn,size))
        return 1;
    //Attempt to place a queen, if the attempt fails, backtrack.
    if(capturedColors[i][j]==VALID && prevQueenColumn-1!=j && prevQueenColumn+1!=j && allowedColumns[j]==VALID) {
        board[i][j]=1;
        allowedColumns[j]=INVALID;
        fillColor(grid,capturedColors,i,j,grid[i][j],INVALID,size);
        int isStepSolve=task4Helper(grid,board,capturedColors,allowedColumns,i+1,0,j,size);
        if(isStepSolve)
            return 1;
        board[i][j]=0;
        allowedColumns[j]=VALID;
        fillColor(grid,capturedColors,i,j,grid[i][j],VALID,size);
    }
    //If it is generally forbidden to place a queen here:
    return 0;
}
/*
 The action receives a location color and value,
the action "spreads" across the board and marks all of that location with the same color and value.
*/
void fillColor(char grid[][MAX_GRID_SIZE],int capturedColors[][MAX_GRID_SIZE],int i,int j,char color,int fillingValue,
    int size) {

    if(i==size || j==size || i<0 || j<0)
        return;
    if(grid[i][j]!=color)
        return;
    if(capturedColors[i][j]==fillingValue)
        return;
    capturedColors[i][j]=fillingValue;
    fillColor(grid,capturedColors,i+1,j,color,fillingValue,size);
    fillColor(grid,capturedColors,i-1,j,color,fillingValue,size);
    fillColor(grid,capturedColors,i,j-1,color,fillingValue,size);
    fillColor(grid,capturedColors,i,j+1,color,fillingValue,size);
}

void task5_crossword_generator(){
    //input:
    int size=0,slotsNum=0;
    printf("Please enter the dimensions of the crossword grid:\n");
    scanf("%d",&size);
    printf("Please enter the number of slots in the crossword:\n");
    scanf("%d",&slotsNum);
    printf("Please enter the details for each slot (Row, Column, Length, Direction):\n");
    Slot slots[MAX_SLOTS_NUM];
    for(int i=0;i<slotsNum;i++) {
        scanf(" %d",&slots[i].row);
        scanf(" %d",&slots[i].column);
        scanf(" %d",&slots[i].length);
        scanf(" %c",&slots[i].direction);
    }
    int wordsNum=0;
    char words[MAX_WORD_SIZE][MAX_WORDS_NUM];
    printf("Please enter the number of words in the dictionary:\n");
    do {
        scanf(" %d",&wordsNum);
        if(wordsNum<slotsNum)
            printf("The dictionary must contain at least %d words. Please enter a valid dictionary size:\n",slotsNum);
    }while(wordsNum<slotsNum);
    printf("Please enter the words for the dictionary:\n");
    for(int i=0;i<wordsNum;i++) {
        scanf(" %s",words[i]);
    }
    //Create a blank board:
    char board[MAX_CROSSWORD_SIZE][MAX_CROSSWORD_SIZE]={0};
    int availableWords[MAX_WORDS_NUM]={VALID};
    //output:
    if(task5Helper(board,size,slots,slotsNum,words,availableWords,wordsNum,0,0)) {
        for(int i=0;i<size;i++) {
            printf("| ");
            for(int j=0;j<size;j++) {
                if(board[i][j]==0)
                    printf("# | ");
                else
                    printf("%c | ",board[i][j]);
            }
            printf("\n");
        }
    }
    else
        printf("This crossword cannot be solved.\n");
}
/*
The operation receives the board and the inputs,
the operation goes through each slot and on each slot tries to place a word.
The operation modifies the board accordingly:
 */
int task5Helper(char board[][MAX_CROSSWORD_SIZE],int size,Slot slots[MAX_SLOTS_NUM],int slotsNum,
    char words [MAX_WORD_SIZE][MAX_WORDS_NUM],int availableWords[MAX_WORDS_NUM],int wordsNum,int currentSlot,
    int currentWord) {
    //base case:
    if(currentSlot == slotsNum)
        return 1;
    //No word matched the current slot, so the puzzle is unsolvable:
    if(currentWord==wordsNum)
        return 0;
    //If we have already used this word then we will move on to the next word.
    if(availableWords[currentWord]==INVALID)
        return task5Helper(board,size,slots,slotsNum,words,availableWords,wordsNum,currentSlot,currentWord+1);
    /*
    Now we will try to place the word in the slot,
    we will create an array that will store the change that was made in the board,
    if no change was made anywhere there will be 0 in the array
     */
    char slotChange[MAX_SLOT_SIZE]={0};
    if((int)strlen(words[currentWord])==slots[currentSlot].length &&
        isFitIn(board,slots[currentSlot],words[currentWord],slotChange,0)) {

        availableWords[currentWord] = INVALID;
        //recursive call:
        if(task5Helper(board,size,slots,slotsNum,words,availableWords,wordsNum,currentSlot+1,0))
            return 1;
        availableWords[currentWord] = VALID;
    }
    //If the word position in this slot is not the solution, we backtrack with the array we created specifically.
    //then we will go to the next word
    safeDelete(board,slots[currentSlot],slotChange,0);
    return task5Helper(board,size,slots,slotsNum,words,availableWords,wordsNum,currentSlot,currentWord+1);
}
/*
The operation receives a word and a slot.
The operation attempts to place the word in the slot and saves any changes made to the board in the array.
 */
int isFitIn(char board[][MAX_CROSSWORD_SIZE],Slot slot,char word[MAX_WORD_SIZE],char slotChange[MAX_SLOT_SIZE],
    int index) {
    //base case:
    if(index==(int)strlen(word))
        return 1;
    //Calculation of which character on the board is being tested now
    int row=slot.row,column=slot.column;
    if(slot.direction == 'V')
        row+=index;
    if(slot.direction=='H')
        column+=index;
    //doesnt match:
    if(board[row][column]!=0 && board[row][column] != word[index])
        return 0;
    //if the board was empty we will save the change:
    if(board[row][column]==0)
        slotChange[index]=word[index];
    board[row][column]=word[index];
    return isFitIn(board,slot,word,slotChange,index+1);
}
//Performing a backtrack, deleting the changes in the board
void safeDelete(char board[][MAX_CROSSWORD_SIZE],Slot slot,char slotChange[MAX_SLOT_SIZE],int index){
    //base case:
    if(index==slot.length)
        return;
    int row=slot.row,column=slot.column;
    if(slot.direction=='V')
        row+=index;
    if(slot.direction=='H')
        column+=index;
    //if was a change we will change it back
    if(slotChange[index]!=0) {
        board[row][column]=0;
    }
    safeDelete(board,slot,slotChange,index+1);
}